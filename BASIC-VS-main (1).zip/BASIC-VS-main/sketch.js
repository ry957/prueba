
var trex ,trex_running;
function preload(){
  

}

function setup(){
  createCanvas(600,200)
  
  //create a trex sprite
 
}

function draw(){
  background("white")
  

}
